batfiles
========

Various useful Windows .bat files
